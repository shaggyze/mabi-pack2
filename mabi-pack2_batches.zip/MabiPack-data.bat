@echo off
set /p file="Enter Filename: "
xcopy ".\data\" ".\temp\data\" /q /s /y /c /e
mabi-patcher.exe pack -i .\temp\ -o ".\%file%" -k "})wWb4?-sVGHNoPKpc"
rmdir /q /s  .\temp\