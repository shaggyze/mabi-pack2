@echo off
setlocal EnableDelayedExpansion
rem Insert in the next line the list of files to skip
set skip=/uotiara_00001/
set path=C:\Nexon\Library\mabinogi\appdata\package
set /p path="Enter Path (Press Enter to keep <%path%>): "
for /r "%path%" %%f in (*.it) do (
   if /I "!skip:/%%~nf/=!" equ "%skip%" (
      mabi-patcher.exe extract -i "%%f" -o . -k "@6QeTuOaDgJlZcBm#9"
   ) else (
      echo Skipped %%f
   )
)
pause