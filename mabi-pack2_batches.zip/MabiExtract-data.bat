@echo off
set /p file="Enter Filename: "
echo Extracting %file% with @6QeTuOaDgJlZcBm#9
mabi-patcher.exe extract -i %file% -o . -k "@6QeTuOaDgJlZcBm#9"
if errorlevel 1 (
	for /f %%s IN (salts.txt) do (
		echo Extracting %file% with %%s
		mabi-patcher.exe extract -i "%file%" -o . -k "%%s"
	)
)